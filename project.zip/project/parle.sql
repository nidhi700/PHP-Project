-- phpMyAdmin SQL Dump
-- version 4.8.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 29, 2019 at 01:29 PM
-- Server version: 10.1.37-MariaDB
-- PHP Version: 7.2.13

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `parle`
--

DELIMITER $$
--
-- Procedures
--
CREATE DEFINER=`root`@`localhost` PROCEDURE `AddProductPro` (IN `Cat_ID` INT, IN `Pro_Code` INT, IN `Pro_Name` VARCHAR(40), IN `Image` VARCHAR(50), IN `Gm` INT, IN `MRP` INT, IN `Pieces` INT, IN `Remark` VARCHAR(50))  NO SQL
insert into product(Cat_ID,Pro_Code,Pro_Name,Image,Gm,MRP,Pieces,Date_Pro,Remark) values(Cat_ID,Pro_Code,Pro_Name,Image,Gm,MRP,Pieces,now(),Remark)$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `order_master` (IN `Order_id` BIGINT, IN `Cust_Id` INT, IN `Amount` INT, IN `Date_order` DATE, IN `Payment_Type` VARCHAR(20))  NO SQL
insert into order_master (Order_id,Cust_Id,Amount,Date_order,Payment_Type) values (Order_id,Cust_Id,Amount,now(),Payment_Type)$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `addtocart`
--

CREATE TABLE `addtocart` (
  `id` int(11) NOT NULL,
  `P_ID` int(11) NOT NULL,
  `Cust_Id` int(11) NOT NULL,
  `Pieces_C` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `addtocart`
--

INSERT INTO `addtocart` (`id`, `P_ID`, `Cust_Id`, `Pieces_C`) VALUES
(6, 1, 2, 9),
(7, 12, 2, 2),
(8, 17, 2, 2),
(9, 9, 2, 2),
(10, 7, 2, 2),
(11, 15, 2, 2);

-- --------------------------------------------------------

--
-- Table structure for table `admin_login`
--

CREATE TABLE `admin_login` (
  `UserName` varchar(20) NOT NULL,
  `Password` varchar(8) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin_login`
--

INSERT INTO `admin_login` (`UserName`, `Password`) VALUES
('asdermarketing', '12345'),
('tejasenterprise', '09876');

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `Cat_ID` int(11) NOT NULL,
  `Cat_Name` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`Cat_ID`, `Cat_Name`) VALUES
(1, 'Biscuits'),
(2, 'Confectionery'),
(3, 'Rusk'),
(4, 'Snacks');

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE `login` (
  `Cust_Id` int(11) NOT NULL,
  `Name` varchar(30) NOT NULL,
  `ShopName` varchar(30) NOT NULL,
  `Shop_Add` varchar(50) NOT NULL,
  `Contact` int(10) NOT NULL,
  `GST` varchar(30) NOT NULL,
  `User_Id` varchar(25) NOT NULL,
  `Password` varchar(8) NOT NULL,
  `Image` varchar(40) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`Cust_Id`, `Name`, `ShopName`, `Shop_Add`, `Contact`, `GST`, `User_Id`, `Password`, `Image`) VALUES
(1, 'Rupesh Patel', 'Kothari Sons', 'skdfskdj', 9998, 'djf34', 'patelpan', 'patel123', '../img/man2.png'),
(2, 'Vipul Kamdar', 'Khodaldham', '150 Ring Road', 1234567890, '111OGh34', 'khdham', '12345678', '../img/man.png'),
(3, 'Darsh Patel', 'Darsh Enterprise', 'Everest Park', 987654321, 'Gj389werd', 'darshent', 'abc123', ''),
(4, 'Rajesh', 'Rajesh Karyana', 'Ambika Park', 234509876, 'AE34RI', 'rajesh', 'rajesh7', '');

-- --------------------------------------------------------

--
-- Table structure for table `order_detail`
--

CREATE TABLE `order_detail` (
  `d_id` int(11) NOT NULL,
  `Order_id` int(11) NOT NULL,
  `Cust_Id` int(11) NOT NULL,
  `Pro_Code` int(11) NOT NULL,
  `MRP` bigint(20) NOT NULL,
  `Pieces_O` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `order_detail`
--

INSERT INTO `order_detail` (`d_id`, `Order_id`, `Cust_Id`, `Pro_Code`, `MRP`, `Pieces_O`) VALUES
(22, 767, 1, 100039, 5, 3),
(23, 767, 1, 1000006, 25, 2),
(24, 767, 1, 1000297, 5, 2),
(25, 767, 1, 100045, 50, 2),
(26, 759, 4, 100045, 50, 2),
(27, 759, 4, 1000297, 5, 1),
(28, 292, 4, 1930480, 10, 1),
(29, 427, 4, 1000297, 5, 1),
(30, 843, 3, 1000418, 2, 2);

-- --------------------------------------------------------

--
-- Table structure for table `order_master1`
--

CREATE TABLE `order_master1` (
  `m_id` int(11) NOT NULL,
  `Order_id` bigint(20) NOT NULL,
  `Cust_Id` int(11) NOT NULL,
  `Amount` int(11) NOT NULL,
  `Date_order` date NOT NULL,
  `Payment_Type` varchar(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `order_master1`
--

INSERT INTO `order_master1` (`m_id`, `Order_id`, `Cust_Id`, `Amount`, `Date_order`, `Payment_Type`) VALUES
(1, 691, 1, 185, '2019-03-15', '0'),
(2, 742, 1, 40, '2019-03-15', '0'),
(3, 924, 1, 5, '2019-03-15', '0'),
(4, 888, 1, 50, '2019-03-15', '0'),
(5, 964, 1, 2, '2019-03-15', '0'),
(6, 458, 1, 105, '2019-03-15', '0'),
(7, 865, 1, 50, '2019-03-15', '0'),
(8, 69, 1, 10, '2019-03-15', '0'),
(9, 798, 3, 5, '2019-03-19', '0'),
(10, 292, 1, 126, '2019-03-20', '0'),
(11, 767, 1, 175, '2019-03-20', '0'),
(12, 759, 4, 105, '2019-03-29', '0'),
(13, 292, 4, 10, '2019-03-29', '0'),
(14, 427, 4, 5, '2019-03-29', 'cash'),
(15, 843, 3, 4, '2019-03-29', 'Online'),
(16, 281, 3, 5, '2019-03-29', 'Cash'),
(17, 371, 3, 40, '2019-03-29', 'Cash'),
(18, 952, 3, 51, '2019-03-29', 'Online');

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

CREATE TABLE `product` (
  `P_ID` int(11) NOT NULL,
  `Cat_ID` int(11) NOT NULL,
  `Pro_Code` int(11) NOT NULL,
  `Pro_Name` varchar(30) NOT NULL,
  `Image` varchar(40) NOT NULL,
  `Gm` int(11) NOT NULL,
  `MRP` int(11) NOT NULL,
  `Pieces` int(11) NOT NULL,
  `Date_Pro` date NOT NULL,
  `Remark` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`P_ID`, `Cat_ID`, `Pro_Code`, `Pro_Name`, `Image`, `Gm`, `MRP`, `Pieces`, `Date_Pro`, `Remark`) VALUES
(1, 1, 1000297, 'Parle-G', '../img/1index.png', 28, 5, 365, '2019-02-06', '-'),
(2, 1, 1000006, 'Hide&Seek Black BB Choco', '../img/h&sBB.png', 100, 25, 360, '2019-02-06', '-'),
(3, 1, 100008, 'Hide&Seek Black BB Vanila', '../img/h&sBBVanila.png', 100, 25, 360, '2019-02-09', '-'),
(4, 1, 1000034, 'Hide&Seek', '../img/Hide&Seek_CaffeMocha.png', 120, 30, 72, '2019-02-09', '-'),
(5, 1, 1000035, 'Hide&Seek Choco', '../img/h&sChoco.png', 33, 10, 144, '2019-02-09', '-'),
(6, 1, 1000322, 'Parle-G Bheem', '../img/pgbheem.png', 70, 5, 144, '2019-02-09', '-'),
(7, 3, 100045, 'Rusk Milk', '../img/ruskmilk.png', 45, 50, 50, '2019-02-11', '-'),
(8, 3, 1000294, 'Rusk Real Elaichi', '../img/rusk1.png', 40, 55, 30, '2019-02-11', '-'),
(9, 2, 109445, 'MazeloFruitJelly Orange', '../img/mfgj.png', 10, 3, 100, '2019-02-13', '-'),
(10, 2, 199442, 'MazeloFruitJelly Lychee', '../img/mfgl.png', 10, 3, 50, '2019-02-13', '-'),
(11, 2, 188956, 'MazeloFruitJelly Guava', '../img/mfgr.png', 10, 3, 50, '2019-02-13', '-'),
(12, 2, 100039, 'Mazelo Guava', '../img/mazeloguava.png', 10, 5, 60, '2019-02-13', '-'),
(13, 2, 278997, 'Kismi ElaichiBar', '../img/kismielaichibar.png', 10, 1, 40, '2019-02-13', '-'),
(14, 2, 190234, 'Kismi Kulffi', '../img/kismikulffi.png', 5, 1, 40, '2019-02-13', '-'),
(15, 3, 1000396, 'Rusk Cake Vanila ', '../img/ruskcake.png', 300, 40, 36, '2019-02-13', '-'),
(17, 2, 1000418, 'Poppins ', '../img/poppins1.png', 16, 2, 1040, '2019-02-13', 'Rolls'),
(18, 2, 1000429, 'Melody Choco', '../img/melodychoco.png', 5, 1, 200, '2019-02-13', '-'),
(19, 3, 1002193, 'Rusk Garlic Bread Toast', '../img/ruskGarlicBreadToast.png', 100, 30, 100, '2019-02-28', '-'),
(20, 4, 123789, 'Snacks Khatta Meetha', '../img/Snacks_KhattaMeetha.png', 30, 40, 30, '2019-03-12', '-'),
(21, 4, 1930480, 'Snacks Creame & Onion', '../img/wafersc&o.png', 30, 10, 30, '2019-03-12', '-');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `addtocart`
--
ALTER TABLE `addtocart`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`Cat_ID`);

--
-- Indexes for table `login`
--
ALTER TABLE `login`
  ADD PRIMARY KEY (`Cust_Id`);

--
-- Indexes for table `order_detail`
--
ALTER TABLE `order_detail`
  ADD PRIMARY KEY (`d_id`);

--
-- Indexes for table `order_master1`
--
ALTER TABLE `order_master1`
  ADD PRIMARY KEY (`m_id`);

--
-- Indexes for table `product`
--
ALTER TABLE `product`
  ADD PRIMARY KEY (`P_ID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `addtocart`
--
ALTER TABLE `addtocart`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `Cat_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `login`
--
ALTER TABLE `login`
  MODIFY `Cust_Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `order_detail`
--
ALTER TABLE `order_detail`
  MODIFY `d_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;

--
-- AUTO_INCREMENT for table `order_master1`
--
ALTER TABLE `order_master1`
  MODIFY `m_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `product`
--
ALTER TABLE `product`
  MODIFY `P_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
