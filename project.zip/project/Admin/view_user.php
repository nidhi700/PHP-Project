<?php
include("db.php");
if(!isset($_SESSION['admin_login']))
  header("location: index.php");


    $sql= "select * from login "; //"call sp()";
    $result=mysqli_query($db,$sql);
    
?>
<!DOCTYPE html>
<html>
<head>
    <meta http-equiv="Content-type" content="text/html; charset=utf-8">
    <meta name="viewport" content="width=device-width,initial-scale=1,user-scalable=no">
    <title>View User</title>
    <link rel="shortcut icon" type="image/png" href="/media/images/favicon.png">
    <link rel="alternate" type="application/rss+xml" title="RSS 2.0" href="http://www.datatables.net/rss.xml">
    <link rel="stylesheet" type="text/css" href="/media/css/site-examples.css?_=19472395a2969da78c8a4c707e72123a">
    <link rel="stylesheet" type="text/css" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.19/css/dataTables.bootstrap.min.css">
    <style type="text/css" class="init">
  
    </style>
    <script type="text/javascript" src="/media/js/site.js?_=5e8f232afab336abc1a1b65046a73460"></script>
    <script type="text/javascript" src="/media/js/dynamic.php?comments-page=examples%2Fstyling%2Fbootstrap.html" async></script>
    <script type="text/javascript" language="javascript" src="https://code.jquery.com/jquery-3.3.1.js"></script>
    <script type="text/javascript" language="javascript" src="https://cdn.datatables.net/1.10.19/js/jquery.dataTables.min.js"></script>
    <script type="text/javascript" language="javascript" src="https://cdn.datatables.net/1.10.19/js/dataTables.bootstrap.min.js"></script>
    <script type="text/javascript" language="javascript" src="../resources/demo.js"></script>
    <script type="text/javascript" class="init">
  
$(document).ready(function() {
    $('#example').DataTable();
} );

    </script>
</head>


<body background="../img/back21.png">
      <a href="logout.php">Logout</a><br/>  
<table id="example" class="table table-striped table-bordered" style="width:100%" >
<thead>
<tr>
<th><strong>Image</strong></th>
<th><strong>Name</strong></th>
<th><strong>Shop Name</strong></th>
<th><strong>Shop Address</strong></th>
<th><strong>Contact</strong></th>
<th><strong>GST</strong></th>
<th><strong>User ID</strong></th>
<th><strong>Password</strong></th>
<th><strong>Edit</strong></th>
<th><strong>Delete</strong></th>
</tr>
</thead>
<tbody>

<?php
while($row = mysqli_fetch_assoc($result)){

	    ?>
    <tr>
        <td align="center"> <img src="<?php echo $row['Image']; ?>"> </td>
    	<td align="center"> <?php echo $row['Name']; ?> </td>
        <td align="center"> <?php echo $row['ShopName']; ?> </td>
        <td align="center"> <?php echo $row['Shop_Add']; ?> </td>
        <td align="center"> <?php echo $row['Contact']; ?> </td>
        <td align="center"> <?php echo $row['GST']; ?> </td>
        <td align="center"> <?php echo $row['User_Id']; ?> </td>
        <td align="center"> <?php echo $row['Password']; ?> </td>
		
		<td align="center"><a href="edit_user.php?Cust_Id=<?php echo $row['Cust_Id']; ?>">Edit</a></td>
		<td align="center"><a href="delete_user.php?Cust_Id=<?php echo $row['Cust_Id']; ?>">Delete</a></td>
	</tr>  

<?php 	}  	?>

</div>
</body>
</html>