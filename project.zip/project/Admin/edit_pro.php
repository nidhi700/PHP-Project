<!DOCTYPE html>
<html lang="en">
<head>
	<title>Edit_Product</title>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
<!--===============================================================================================-->	
	<link rel="icon" type="image/png" href="images/icons/favicon.ico"/>
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/bootstrap/css/bootstrap.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="fonts/font-awesome-4.7.0/css/font-awesome.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="fonts/iconic/css/material-design-iconic-font.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/animate/animate.css">
<!--===============================================================================================-->	
	<link rel="stylesheet" type="text/css" href="vendor/css-hamburgers/hamburgers.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/animsition/css/animsition.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/select2/select2.min.css">
<!--===============================================================================================-->	
	<link rel="stylesheet" type="text/css" href="vendor/daterangepicker/daterangepicker.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="css/util.css">
	<link rel="stylesheet" type="text/css" href="css/main.css">
<!--===============================================================================================-->
</head>


<?php

	require_once('db.php');
    if(!isset($_SESSION['admin_login']))
        header("location: index.php");


    
    $id=$_GET['P_ID'];
    $sql= "select * from product where P_ID = $id ";

    $result=mysqli_query($db,$sql);
    $row = mysqli_fetch_assoc($result);

    if(isset($_POST["submit"]))
    {
        if( $_FILES['fileToUpload']['name']  == "")
        { 
            $t_file=$row['Image'];
            echo $t_file;        
        }
        else
        {
            $t_file = '../img/' . basename($_FILES["fileToUpload"]["name"]);
            if (move_uploaded_file($_FILES["fileToUpload"]["tmp_name"], $t_file))
            {
                //echo "The file ". basename( $_FILES["fileToUpload"]["name"]). " has been Uploaded. <br>";
            }       
        }    
        
        $cat_id=$_POST['cat_id'];
        $pcode=$_POST['pcode'];
        $pname=$_POST['pname'];
        $gm=$_POST['gm'];
        $mrp=$_POST['mrp'];
        $pcs=$_POST['pcs'];
        $remark=$_POST['remark'];

        $sql1="update product set Cat_ID=$cat_id , Pro_Code=$pcode , Pro_Name='$pname' , Image='$t_file' , Gm=$gm , MRP=$mrp , Pieces=$pcs , Remark='$remark' where P_ID=$id";
        //mysqli_query($db,$sql1);
        if(mysqli_query($db,$sql1))
        {
        	header("location: display_product.php");
        	
        }
    }   
?>



<body >
	
	
	<div class="container-login100" style="background-image: url('../img/Jeera20-20.png');">
		<div class="wrap-login100 p-l-55 p-r-55 p-t-80 p-b-30">
			
			<form class="login100-form validate-form" enctype="multipart/form-data" method="post" >
			
				<span class="login100-form-title p-b-37">
					Edit Product
				</span>

				<div class="wrap-input100 validate-input m-b-20">
					<input class="input100" type="text" name="cat_id" placeholder="Category_ID" value="<?php echo $row['Cat_ID']; ?>">
					<span class="focus-input100"></span>
				</div>
				
				<div class="wrap-input100 validate-input m-b-20">
					<input class="input100" type="text" name="pcode" placeholder="Product Code" value="<?php echo $row['Pro_Code']; ?>">
					<span class="focus-input100"></span>
				</div>
				
				<div class="wrap-input100 validate-input m-b-20">
					<input class="input100" type="text" name="pname" placeholder="Product Name" value="<?php echo $row['Pro_Name']; ?>">
					<span class="focus-input100"></span>
				</div>				
				
				<div class="wrap-input100 validate-input m-b-20">
					<input class="input100" type="text" name="gm" placeholder="Gram(gm)" value="<?php echo $row['Gm']; ?>">
					<span class="focus-input100"></span>
				</div>
				
				<div class="wrap-input100 validate-input m-b-20">
					<input class="input100" type="text" name="mrp" placeholder="MRP" value="<?php echo $row['MRP']; ?>">
					<span class="focus-input100"></span>
				</div>
				
				<div class="wrap-input100 validate-input m-b-20">
					<input class="input100" type="text" name="pcs" placeholder="Pieces" value="<?php echo $row['Pieces']; ?>">
					<span class="focus-input100"></span>
				</div>
				
				<div class="wrap-input100 validate-input m-b-20">
					<input class="input100" type="text" name="remark" placeholder="Remark" value="<?php echo $row['Remark']; ?>" >
					<span class="focus-input100"></span>
				</div>

				<center>
					<img width="100px" src= "<?php echo $row['Image']; ?>" /><br>
                    <?php echo $row['Image']; ?> <br>
				</center>
                    <br>
                
                
                
                <input type="hidden" name="file" value="<?php echo $row['Image']; ?>">
                <input type="file" name="fileToUpload" id="fileToUpload">
                <input type="hidden" name="id" value="<?php echo $id; ?>">
                <br>
                <br>    
                
                    <center><input type="submit" class="login100-form-btn" value="Update" name="submit" ></center>
               
				<br>
				<br>			

				</form>
		</div>
	</div>
	
	

	<div id="dropDownSelect1"></div>
	
<!--===============================================================================================-->
	<script src="vendor/jquery/jquery-3.2.1.min.js"></script>
<!--===============================================================================================-->
	<script src="vendor/animsition/js/animsition.min.js"></script>
<!--===============================================================================================-->
	<script src="vendor/bootstrap/js/popper.js"></script>
	<script src="vendor/bootstrap/js/bootstrap.min.js"></script>
<!--===============================================================================================-->
	<script src="vendor/select2/select2.min.js"></script>
<!--===============================================================================================-->
	<script src="vendor/daterangepicker/moment.min.js"></script>
	<script src="vendor/daterangepicker/daterangepicker.js"></script>
<!--===============================================================================================-->
	<script src="vendor/countdowntime/countdowntime.js"></script>
<!--===============================================================================================-->
	<script src="js/main.js"></script>

</body>
</html>