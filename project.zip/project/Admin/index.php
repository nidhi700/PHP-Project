<!DOCTYPE html>
<html lang="en">
<head>
<title>Admin login</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Fashion Club Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<!-- css -->
<link href="css/bootstrap.css" rel="stylesheet" type="text/css" media="all" />
<link rel="stylesheet" href="css/style.css" type="text/css" media="all" />
<link rel="stylesheet" href="css/font-awesome.min.css" type="text/css" media="all" />
<!--// css -->
<!-- font -->
<link href="//fonts.googleapis.com/css?family=Source+Sans+Pro" rel="stylesheet">
<link href='//fonts.googleapis.com/css?family=Open+Sans:400,300,300italic,400italic,600,600italic,700,700italic,800,800italic' rel='stylesheet' type='text/css'>
<!-- //font -->
<script src="js/jquery-1.11.1.min.js"></script>
<script src="js/bootstrap.js"></script>
</head>
<?php
	   require_once("db.php");
   
	   if($_SERVER["REQUEST_METHOD"] == "POST") {
      // username and password sent from form
     
	      $myusername = $_POST['username'];
	      $mypassword = $_POST['password'];
	     
	      $sql = "SELECT * FROM admin_login WHERE UserName = '$myusername' and Password = '$mypassword'";
	      $result = mysqli_query($db,$sql);
	      $row = mysqli_fetch_array($result);
	         
	      $count = mysqli_num_rows($result);
	     
	      // If result matched $myusername and $mypassword, table row must be 1 row
	       
	    if($count == 1) 
	    {
	        $_SESSION['admin_login'] = $myusername;
	    	header("location: display_product.php");
	    }
	    else 
	    {
		    echo "Your Login Name or Password is invalid";
	    }
	}

?>

<body>
<div class="login">
	
		<div class="main-agileits">
			<div class="form-w3agile">
					<h3>Admin Login</h3>
					<form action="#" method="post">

						<div class="key">
							<i class="glyphicon glyphicon-pencil" aria-hidden="true"></i>
							<input  type="text" name="username" required="" placeholder="Username">
							<div class="clearfix"></div>
						</div>
						<div class="key">
							<i class="fa fa-lock" aria-hidden="true"></i>
							<input  type="password" name="password" required="" placeholder="Password">
							<div class="clearfix"></div>
						</div>
						<input type="submit" value="Login">
					</form>
				</div>
				<div class="forg">
					<!-- <a href="#" class="forg-left">Forgot Password</a> -->
					
				<div class="clearfix"></div>
			</div>
		</div>
	</body>
	</html>