<?php
    require_once("db.php");
    if(!isset($_SESSION['admin_login']))
        header("location: index.php");


    $sql= "select * from order_master1 "; //"call sp()";
    $result=mysqli_query($db,$sql);
    
?>
<!DOCTYPE html>
<html>
<head>
    <meta http-equiv="Content-type" content="text/html; charset=utf-8">
    <meta name="viewport" content="width=device-width,initial-scale=1,user-scalable=no">
    <title>Monthly Report</title>
    <link rel="shortcut icon" type="image/png" href="/media/images/favicon.png">
    <link rel="alternate" type="application/rss+xml" title="RSS 2.0" href="http://www.datatables.net/rss.xml">
    <link rel="stylesheet" type="text/css" href="/media/css/site-examples.css?_=19472395a2969da78c8a4c707e72123a">
    <link rel="stylesheet" type="text/css" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.19/css/dataTables.bootstrap.min.css">
    <style type="text/css" class="init">
  
    </style>
    <script type="text/javascript" src="/media/js/site.js?_=5e8f232afab336abc1a1b65046a73460"></script>
    <script type="text/javascript" src="/media/js/dynamic.php?comments-page=examples%2Fstyling%2Fbootstrap.html" async></script>
    <script type="text/javascript" language="javascript" src="https://code.jquery.com/jquery-3.3.1.js"></script>
    <script type="text/javascript" language="javascript" src="https://cdn.datatables.net/1.10.19/js/jquery.dataTables.min.js"></script>
    <script type="text/javascript" language="javascript" src="https://cdn.datatables.net/1.10.19/js/dataTables.bootstrap.min.js"></script>
    <script type="text/javascript" language="javascript" src="../resources/demo.js"></script>
    <script type="text/javascript" class="init">
  
$(document).ready(function() {
    $('#example').DataTable();
} );

    </script>
</head>


<body background="../img/back21.png">

<a href="logout.php">Logout</a><br/>
<a href="AddProduct.php">Add Product</a><br/>
<a href="view_user.php">View User</a>

<table id="example" class="table table-striped table-bordered" style="width:100%" border="3" >
<thead>
<tr align="center">
<th><strong>Category ID</strong></th>
<th><strong>Product Code</strong></th>
<th><strong>Product Name</strong></th>
<th><strong>Image</strong></th>
<th><strong>Gram</strong></th>
<th><strong>MRP</strong></th>
<th><strong>Pieces</strong></th>
<th><strong>Date</strong></th>
<th><strong>Remark</strong></th>
<th><strong>Edit</strong></th>
<th><strong>Delete</strong></th>
</tr>
</thead>
<tbody>

<?php
while($row = mysqli_fetch_assoc($result)){

	    ?>
    <tr>
    	<td align="center" style="padding-top: 50px"> <?php echo $row['Cat_ID']; ?> </td>
		<td align="center" style="padding-top: 50px"> <?php echo $row['Pro_Code']; ?> </td>
		<td align="center" style="padding-top: 50px"> <?php echo $row['Pro_Name']; ?> </td>
		<td align="center"> <img width=100px height="100px" src= <?php echo $row['Image']; ?> /> </td>
		<td align="center" style="padding-top: 50px"> <?php echo $row['Gm']; ?></td>
		<td align="center" style="padding-top: 50px"> <?php echo $row['MRP']; ?></td>
		<td align="center" style="padding-top: 50px"> <?php echo $row['Pieces']; ?></td>
        <td align="center" style="padding-top: 50px"> <?php echo $row['Date_Pro']; ?></td>
		<td align="center" style="padding-top: 50px"> <?php echo $row['Remark']; ?></td>
		
		<td align="center" style="padding-top: 50px"><a href="edit_pro.php?P_ID=<?php echo $row['P_ID']; ?>">Edit</a></td>
		<td align="center" style="padding-top: 50px"><a href="delete_product.php?P_ID=<?php echo $row['P_ID']; ?>">Delete</a></td>
	</tr>  

<?php 	}  	?>
</tbody>
</body>
</html>