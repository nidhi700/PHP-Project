<?php

	require_once('db.php');
    if(!isset($_SESSION['admin_login']))
        header("location: index.php");
	
	$id = $_GET['Cust_Id'];
	$sql= "delete from login where Cust_Id = $id";
	$result=mysqli_query($db,$sql);
	header("location: view_user.php");
?>