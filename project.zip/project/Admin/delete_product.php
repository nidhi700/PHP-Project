<?php

	require_once('db.php');
    if(!isset($_SESSION['admin_login']))
        header("location: index.php");
    
	$id = $_GET['P_ID'];
	$sql= "delete from product where P_ID = $id";
	$result=mysqli_query($db,$sql);
	header("location: display_product.php");
?>