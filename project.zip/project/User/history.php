<?php
require_once('db.php');
if($_SESSION['name']==null)
{
	header("location: login.php");	
}
else
{
	$uid=$_SESSION['id'];	
	$sql="select * from order_master1 where Cust_Id=$uid";
	$result=mysqli_query($db,$sql);
?>

<!DOCTYPE html>
<html>
<head>
    <meta http-equiv="Content-type" content="text/html; charset=utf-8">
    <meta name="viewport" content="width=device-width,initial-scale=1,user-scalable=no">
    <title>History</title>
    <link rel="shortcut icon" type="image/png" href="/media/images/favicon.png">
    <link rel="alternate" type="application/rss+xml" title="RSS 2.0" href="http://www.datatables.net/rss.xml">
    <link rel="stylesheet" type="text/css" href="/media/css/site-examples.css?_=19472395a2969da78c8a4c707e72123a">
    <link rel="stylesheet" type="text/css" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.19/css/dataTables.bootstrap.min.css">
    <style type="text/css" class="init">
  
    </style>
    <script type="text/javascript" src="/media/js/site.js?_=5e8f232afab336abc1a1b65046a73460"></script>
    <script type="text/javascript" src="/media/js/dynamic.php?comments-page=examples%2Fstyling%2Fbootstrap.html" async></script>
    <script type="text/javascript" language="javascript" src="https://code.jquery.com/jquery-3.3.1.js"></script>
    <script type="text/javascript" language="javascript" src="https://cdn.datatables.net/1.10.19/js/jquery.dataTables.min.js"></script>
    <script type="text/javascript" language="javascript" src="https://cdn.datatables.net/1.10.19/js/dataTables.bootstrap.min.js"></script>
    <script type="text/javascript" language="javascript" src="../resources/demo.js"></script>
    <script type="text/javascript" class="init">
  
$(document).ready(function() {
    $('#example').DataTable();
} );

    </script>
</head>
<body>
	<?php require_once('header.php'); ?>

<br><br><br><br><br><br><br>
<table id="example" class="table table-striped table-bordered" style="width:100%" border="3" >
<thead>
<tr align="center">
<th><strong>Date</strong></th>
<th><strong>Order #</strong></th>
<th><strong>Amount</strong></th>
<th><strong>Payment Method</strong></th>
</tr>
</thead>
<tbody>

<?php
while($row = mysqli_fetch_assoc($result)){

	    ?>
    <tr>
    	<td align="center" style="padding-top: 50px"> <?php echo $row['Date_order']; ?> </td>
		<td align="center" style="padding-top: 50px"> <?php echo $row['Amount']; ?> </td>
		<td align="center" style="padding-top: 50px"> <?php echo $row['Order_id']; ?> </td>
		<td align="center" style="padding-top: 50px"><?php echo $row['Payment_Type']; ?> </td>	
	</tr>  

<?php 	}  	?>
</tbody>

</table></body></html>
<?php require_once('footer.php');
}
 ?>