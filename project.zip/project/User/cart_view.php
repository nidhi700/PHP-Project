<?php
require_once('db.php');
if($_SESSION['name']==null)
{
	header("location: login.php");	
}
else
{

?>
<!doctype html>
<html lang="en">

<head>
    <meta http-equiv="Content-type" content="text/html; charset=utf-8">
    <meta name="viewport" content="width=device-width,initial-scale=1,user-scalable=no">
    <title>View Product</title>
    <link rel="shortcut icon" type="image/png" href="/media/images/favicon.png">
    <link rel="alternate" type="application/rss+xml" title="RSS 2.0" href="http://www.datatables.net/rss.xml">
    <link rel="stylesheet" type="text/css" href="/media/css/site-examples.css?_=19472395a2969da78c8a4c707e72123a">
    <link rel="stylesheet" type="text/css" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.19/css/dataTables.bootstrap.min.css">
    <style type="text/css" class="init">
  
    </style>
    <script type="text/javascript" src="/media/js/site.js?_=5e8f232afab336abc1a1b65046a73460"></script>
    <script type="text/javascript" src="/media/js/dynamic.php?comments-page=examples%2Fstyling%2Fbootstrap.html" async></script>
    <script type="text/javascript" language="javascript" src="https://code.jquery.com/jquery-3.3.1.js"></script>
    <script type="text/javascript" language="javascript" src="https://cdn.datatables.net/1.10.19/js/jquery.dataTables.min.js"></script>
    <script type="text/javascript" language="javascript" src="https://cdn.datatables.net/1.10.19/js/dataTables.bootstrap.min.js"></script>
    <script type="text/javascript" language="javascript" src="../resources/demo.js"></script>
    <script type="text/javascript" class="init">
  
$(document).ready(function() {
    $('#example').DataTable();
} );

    </script>
</head>


<body>

	<!--================Header Menu Area =================-->
	<?php
		//require_once('db.php');
		require_once('header.php');
	?>
	<!--================Header Menu Area =================-->

	<!--================Home Banner Area =================-->
	<br><br><br><br><br>
		<img src="../img/urmypg.png" width="100%">
	
	<!--================End Home Banner Area =================-->

	<!--================Cart Area =================-->
		<!--================Clients Logo Area =================-->

	<section class="clients_logo_area">
		<div class="container-fluid">
			<div class="clients_slider owl-carousel">
				<div class="item">
					<img src="../img/l1.png" alt="abc">
				</div>
				<div class="item">
					<img src="../img/l2.png" alt="def">
				</div>
				
			</div>
		</div>
	</section>
	<!--================End Clients Logo Area =================-->



	<br/><br/>
					<table id="example" class="table table-striped table-bordered" style="width:100%" border="3" >
						<thead>
								<th ><strong>Product</th>
								<th ><strong>Price</th>
								<th ><strong>Quantity</th>
								<th ><strong>Total</th>
							</tr>
						</thead>
						<tbody>		

<?php

$uid=$_SESSION['id'];
$sql= "select * from addtocart a ,product p where p.P_ID=a.P_ID and Cust_Id=$uid";
$tot=0;
$results=mysqli_query($db,$sql);
	while($row = mysqli_fetch_assoc($results))
	{
?>
							<tr>
								<td>
									<img src="<?php echo $row['Image']; ?>" width="40px" height="40px">
									&nbsp;&nbsp;&nbsp;<?php echo $row['Pro_Name']; ?>
									
								</td>
								<td align="center">
									<h5>Rs. <?php echo $row['MRP']; ?></h5>
								</td>
								<td align="center">

										<button 
										onclick="var result = document.getElementById('sst<?php echo $row['id']?>'); 
											var sst = result.value; 
											if( !isNaN( sst ) &amp;&amp; sst > 0 )
												result.value--;
											addcart(<?php echo $row['P_ID']?>,'m');
											return false;"									
										 type="button"> -- </button>

										<input type="text" name="qty" id="sst<?php echo $row['id']?>" size="3" value="<?php echo $row['Pieces_C']; ?>" />
										
										<button 
										onclick="var result = document.getElementById('sst<?php echo $row['id']?>'); 
											var sst = result.value; 
											if( !isNaN( sst )) 
												result.value++;
											addcart(<?php echo $row['P_ID']?>,'p');
											return false;"
										 type="button"> + </button>								
																				
								</td>
								<td align="center">
									<h5>
										<?php echo $row['Pieces_C']*$row['MRP']."₹"; 
											$_SESSION['total']=($tot+=$row['Pieces_C']*$row['MRP']);
										?>										
									</h5>
								</td>
							</tr>
<?php }
	?>


							<tr>
								<td align="center" colspan="2">
									<h5>Subtotal</h5>
								</td>
								<td align="center">
									<h5><?php echo $tot; ?>₹</h5>
								</td>
								<td align="center">
									<a href="FinalPayment.php"><button>CheckOut</button></a>
								</td>
							</tr>
						</tbody>
					</table>
				
	<!--================End Cart Area =================-->

	<!--================ Subscription Area ================-->
	<?php 
		require_once('footer.php');
	?>
	<!--================ End footer Area  =================-->



<script>
function addcart(pid,pcs) 
{
  var xhttp;   
  
  xhttp = new XMLHttpRequest();
  xhttp.onreadystatechange = function() {
    if (this.readyState == 4 && this.status == 200) {
        if(this.responseText==0)
            window.location.href = "login.php";
      //alert(this.responseText);
       location.reload();
    }
  };
  //alert("cart1.php?P_ID="+pid+"&Pieces_C="+pcs);
  xhttp.open("GET", "cart1.php?P_ID="+pid+"&Pieces_C="+pcs, true);
  xhttp.send();
}
</script>

	<!-- Optional JavaScript -->
	<!-- jQuery first, then Popper.js, then Bootstrap JS -->
	<script src="js/jquery-3.2.1.min.js"></script>
	<script src="js/popper.js"></script>
	<script src="js/bootstrap.min.js"></script>
	<script src="js/stellar.js"></script>
	<script src="vendors/lightbox/simpleLightbox.min.js"></script>
	<script src="vendors/nice-select/js/jquery.nice-select.min.js"></script>
	<script src="vendors/isotope/imagesloaded.pkgd.min.js"></script>
	<script src="vendors/isotope/isotope-min.js"></script>
	<script src="vendors/owl-carousel/owl.carousel.min.js"></script>
	<script src="js/jquery.ajaxchimp.min.js"></script>
	<script src="js/mail-script.js"></script>
	<script src="vendors/jquery-ui/jquery-ui.js"></script>
	<script src="vendors/counter-up/jquery.waypoints.min.js"></script>
	<script src="vendors/counter-up/jquery.counterup.js"></script>
	<script src="js/theme.js"></script>

<?php } ?>
</body>

</html>