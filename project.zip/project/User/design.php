<!doctype html>
<html lang="en">
<head>
	<script src="js/jquery-3.2.1.min.js"></script>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>

.text1{
	font-family: fantasy;
	padding: 20px;	
	padding-left: 47%;
	letter-spacing: 2px;

}
.abc{
	padding-left: 30%;
}
.text-block {
	opacity: .7;
  position: absolute;
  bottom: 20px;  
  background-color: black;  
  height: 11%;
  width: 100%;
 	margin-top: 30%;
 	align-content: center;  
  
}
</style>
</head>
