<!doctype html>
<html lang="en">
<head>
	<script src="js/jquery-3.2.1.min.js"></script>

</head>

<body>


<?php
	require_once("header.php");
?>
	<!--================Home Banner Area =================-->
	<br/><br/><br/>
	<section class="banner_area">
		<img src="../img/Rusk.png" width="100%">
	</section><!--================End Home Banner Area =================-->
<br><center><h1><u>Grab Your Flavoures...	</u></h1></center>
   	<?php
	require_once("db.php");	
    $sql= "select * from product where pro_name like 'Rusk%'"; //"call sp()";
    $result=mysqli_query($db,$sql);


?>
<div class="container">
<div class="row">
						
<?php
	foreach ($result as $results) 
	{?>
		<div class="col-lg-6"><center>
		<?php
        echo '<img src="'.$results['Image'].'"/>';	
		echo $results['Pro_Name']; 
		echo '<br/>';
    	echo $results['MRP'];echo '<br/>';
		echo '<input type="button" value="Add To Cart" onclick="addcart('.$results['P_ID'].')" />';    	
	?>
   			</center></div>
    	<?php
	}

?>	</div>	</div>



 <script>
function addcart(pid) {
  var xhttp;   
  
  xhttp = new XMLHttpRequest();
  xhttp.onreadystatechange = function() {
    if (this.readyState == 4 && this.status == 200) {
        if(this.responseText==0)
            window.location.href = "login.php";
      alert(this.responseText);
    }
  };
  xhttp.open("GET", "cart.php?P_ID="+pid, true);
  xhttp.send();
}
</script>
	 
	
<?php
	require_once("footer.php");
?>



	<!-- Optional JavaScript -->
	<!-- jQuery first, then Popper.js, then Bootstrap JS -->
	
	<script src="js/popper.js"></script>
	<script src="js/bootstrap.min.js"></script>
	<script src="js/stellar.js"></script>
	<script src="vendors/lightbox/simpleLightbox.min.js"></script>
	<script src="vendors/nice-select/js/jquery.nice-select.min.js"></script>
	<script src="vendors/isotope/imagesloaded.pkgd.min.js"></script>
	<script src="vendors/isotope/isotope-min.js"></script>
	<script src="vendors/owl-carousel/owl.carousel.min.js"></script>
	<script src="js/jquery.ajaxchimp.min.js"></script>
	<script src="js/mail-script.js"></script>
	<script src="vendors/jquery-ui/jquery-ui.js"></script>
	<script src="vendors/counter-up/jquery.waypoints.min.js"></script>
	<script src="vendors/counter-up/jquery.counterup.js"></script>
	<script src="js/theme.js"></script>
</body>

</html>