<?php
	require_once('db.php');

?>

<!DOCTYPE html>
<html lang="en">
<head>
	<title>Registration</title>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
<!--===============================================================================================-->	
	<link rel="icon" type="image/png" href="images/icons/favicon.ico"/>
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/bootstrap/css/bootstrap.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="fonts/font-awesome-4.7.0/css/font-awesome.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="fonts/iconic/css/material-design-iconic-font.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/animate/animate.css">
<!--===============================================================================================-->	
	<link rel="stylesheet" type="text/css" href="vendor/css-hamburgers/hamburgers.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/animsition/css/animsition.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/select2/select2.min.css">
<!--===============================================================================================-->	
	<link rel="stylesheet" type="text/css" href="vendor/daterangepicker/daterangepicker.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="css/util.css">
	<link rel="stylesheet" type="text/css" href="css/main.css">
<!--===============================================================================================-->
</head>

<!-- 
<?php
	
	/*include('db.php');
	if(!isset($_SESSION['admin_login']))
  		header("location: index.php");
	if(isset($_POST["submit"]))
	{
		$cat_id=$_POST['cat_id'];
		$pcode=$_POST['pcode'];
		$pname=$_POST['pname'];

		$t_file = "../img/" . basename( $_FILES['pimg1']['name']);
		move_uploaded_file( $_FILES['pimg1']['tmp_name'] , $t_file);

		$gm=$_POST['gm'];
		$mrp=$_POST['mrp'];
		$pcs=$_POST['pcs'];
		$remark=$_POST['remark'];

		$sql="call AddProductPro($cat_id,$pcode,'$pname','$t_file',$gm,$mrp,$pcs,'$remark')";
		
    	if(mysqli_query($db,$sql))
        	echo "Record Saved Successfully";
	}*/
?>


 -->
<body>
	
	
	<div class="container-login100" style="background-image: url('../img/Gluco1.png');">
		<div class="wrap-login100 p-l-55 p-r-55 p-t-80 p-b-30">
			
			<form class="login100-form validate-form" enctype="multipart/form-data" method="post" action="router-reg.php">
			
				<span class="login100-form-title p-b-37">
					Register
				</span>

				<div class="wrap-input100 validate-input m-b-20">
					<input class="input100" type="text" name="Name" placeholder="Name">
					<span class="focus-input100"></span>
				</div>
				
				<div class="wrap-input100 validate-input m-b-20">
					<input class="input100" type="text" name="ShopName" placeholder="ShopName">
					<span class="focus-input100"></span>
				</div>
				
				<div class="wrap-input100 validate-input m-b-20">
					<input class="input100" type="text" name="Shop_Add" placeholder="Shop_Add">
					<span class="focus-input100"></span>
				</div>				
				
				<div class="wrap-input100 validate-input m-b-20">
					<input class="input100" type="text" name="Contact" placeholder="Contact">
					<span class="focus-input100"></span>
				</div>
				
				<div class="wrap-input100 validate-input m-b-20">
					<input class="input100" type="text" name="GST" placeholder="GST">
					<span class="focus-input100"></span>
				</div>
				
				<div class="wrap-input100 validate-input m-b-20">
					<input class="input100" type="text" name="User_Id" placeholder="User_Id">
					<span class="focus-input100"></span>
				</div>

				<div class="wrap-input100 validate-input m-b-20">
					<input class="input100" type="password" name="Password" placeholder="Password">
					<span class="focus-input100"></span>
				</div>

				<div class="wrap-input100 validate-input m-b-20">
					<input class="input100" type="password" name="ConfirmPassword" placeholder="ConfirmPassword">
					<span class="focus-input100"></span>
				</div>	

				<div class="wrap-input100 validate-input m-b-20">
					<input class="input100" type="file" name="pimg1">
					<span class="focus-input100"></span>
				</div>
				
					<center><input type="submit" class="login100-form-btn" value="Register" name="submit" ></center>
				
				

				</form>
		</div>
	</div>
	
	

	<div id="dropDownSelect1"></div>
	
<!--===============================================================================================-->
	<script src="vendor/jquery/jquery-3.2.1.min.js"></script>
<!--===============================================================================================-->
	<script src="vendor/animsition/js/animsition.min.js"></script>
<!--===============================================================================================-->
	<script src="vendor/bootstrap/js/popper.js"></script>
	<script src="vendor/bootstrap/js/bootstrap.min.js"></script>
<!--===============================================================================================-->
	<script src="vendor/select2/select2.min.js"></script>
<!--===============================================================================================-->
	<script src="vendor/daterangepicker/moment.min.js"></script>
	<script src="vendor/daterangepicker/daterangepicker.js"></script>
<!--===============================================================================================-->
	<script src="vendor/countdowntime/countdowntime.js"></script>
<!--===============================================================================================-->
	<script src="js/main.js"></script>



</body>
</html>