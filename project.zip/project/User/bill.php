<?php
require_once('db.php');
if($_SESSION['name']==null)
{
	header("location: login.php");	
}
else
{

	$uid=$_SESSION['id'];
	$type=$_SESSION['order_id'];
	$sql= "select * from login where Cust_Id=$uid";
	$results=mysqli_query($db,$sql);
	$row = mysqli_fetch_assoc($results);	
	$name=$row['Name'];
	$mob1=$row['Contact'];
	$add=$row['Shop_Add'];


	$sql1= "select * from login a , order_master1 p where p.Cust_Id=$uid and a.Cust_Id=$uid and Order_id='$type'";
	$result=mysqli_query($db,$sql1);
	$row1 = mysqli_fetch_assoc($result);
	

	?>
	<!doctype html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<title>Parle</title>
	  	<link rel="icon" type="image/x-icon" class="js-site-favicon" href="../img/logo1.ico">
</head>
<body>

	<!--================Home Banner Area =================-->
	
	<!-- <section class="banner_area">
		<div class="banner_inner d-flex align-items-center">
			<div class="container">
				<div class="banner_content text-center">
					<h2>Order Confirmation</h2>
					<div class="page_link">
						<a href="index.html">Home</a>
						<a href="confirmation.html">Confirmation</a>
					</div>
				</div>
			</div>
		</div>
	</section> -->
	<!--================End Home Banner Area =================-->
<img src="../img/MagixCreme12.png" width="100%">

	<!--================Order Details Area =================-->
	<section class="order_details p_120">
		<div class="container">
			<h3 class="title_confirmation">Thank you <?php echo $name;?>.<br> Your order has been received.</h3>
			<div class="row order_d_inner">
				<div class="col-lg-4">
					<div class="details_item">
						<h4>Order Info</h4>
						<ul class="list">
							<li>
								<a href="#">
									<span>Order number</span> : <?php echo $row1['Order_id'];
									?></a>
							</li>
							<li>
								<a href="#">
									<span>Date</span> : <?php echo $row1['Date_order']; ?></a>
							</li>
							<li>
								<a href="#">
									<span>Total</span> : <?php echo "Rs. ".$_SESSION['total']; ?></a>
							</li>
							<li>
								<a href="#">
									<span>Payment method</span> : <?php echo $row1['Payment_Type']; ?></a>
							</li>
						</ul>
					</div>
				</div>
				<div class="col-lg-4">
					<div class="details_item">
						<h4>Billing Address</h4>
						<ul class="list">
							<li>
								<a href="#">
									<span>Street</span> : <?php echo $add; ?></a>
							</li>
							<li>
								<a href="#">
									<span>City</span> : Rajkot</a>
							</li>
							<li>
								<a href="#">
									<span>Country</span> : India</a>
							</li>
							<li>
								<a href="#">
									<span>Postcode </span> : 36952</a>
							</li>
						</ul>
					</div>
				</div>
				<div class="col-lg-4">
					<div class="details_item">
						<h4>Shipping Address</h4>
						<ul class="list">
							<li>
								<a href="#">
									<span>Street</span> : Ayodhya Chowk</a>
							</li>
							<li>
								<a href="#">
									<span>City</span> : Rajkot</a>
							</li>
							<li>
								<a href="#">
									<span>Country</span> : India</a>
							</li>
							<li>
								<a href="#">
									<span>Postcode </span> : 360006</a>
							</li>
						</ul>
					</div>
				</div>
			</div>
			<div class="order_details_table">
				<h2>Total : <?php echo "Rs. ".$_SESSION['total']; ?></h2>				
			</div>
			<center><a href="index.php"><button class="main_btn">Continue Shopping</button></a></center>
		</div>
	</section>

	<!--================End Order Details Area =================-->

<?php
	require_once("footer.php");
?>
	<!-- Optional JavaScript -->
	<!-- jQuery first, then Popper.js, then Bootstrap JS -->
	<script src="js/jquery-3.2.1.min.js"></script>
	<script src="js/popper.js"></script>
	<script src="js/bootstrap.min.js"></script>
	<script src="js/stellar.js"></script>
	<script src="vendors/lightbox/simpleLightbox.min.js"></script>
	<script src="vendors/nice-select/js/jquery.nice-select.min.js"></script>
	<script src="vendors/isotope/imagesloaded.pkgd.min.js"></script>
	<script src="vendors/isotope/isotope-min.js"></script>
	<script src="vendors/owl-carousel/owl.carousel.min.js"></script>
	<script src="js/jquery.ajaxchimp.min.js"></script>
	<script src="js/mail-script.js"></script>
	<script src="vendors/jquery-ui/jquery-ui.js"></script>
	<script src="vendors/counter-up/jquery.waypoints.min.js"></script>
	<script src="vendors/counter-up/jquery.counterup.js"></script>
	<script src="js/theme.js"></script>
</body>

</html>
<?php } ?>