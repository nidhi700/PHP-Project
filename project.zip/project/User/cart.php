<?php
require_once('db.php');

 
if(!isset($_SESSION['id']))
{
	echo 0;
}
else
{
  	$uid=$_SESSION['id'];
 	$id= $_GET['P_ID'];
 	$sql="select Pieces_C from addtocart where Cust_Id=$uid and P_ID=$id";
 	$result=mysqli_query($db,$sql);
 	$row = mysqli_fetch_assoc($result);
 	
 	if($row['Pieces_C']>0)
   		$sql="update  addtocart set Pieces_C=Pieces_C+1  where Cust_Id=$uid and P_ID=$id";
	else
  		$sql="insert into addtocart(Cust_Id,P_ID,Pieces_C) values($uid,$id,1)";
 	

 	if(mysqli_query($db,$sql))
  		echo "Record Added";
 	else
  		echo "Somthing Wrong";
}
?>
