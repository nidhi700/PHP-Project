<?php

	require_once('db.php');
?>
<!doctype html>
<html lang="en">

<body>
<?php
	require_once("header.php");
	//require_once("design.php");
?>
	<!--================Home Banner Area =================-->
	<br/><br/><br/><br/><br/>
	<section class="banner_area">
		<img src="../img/TwoinOne_Eclasirs.png" width="100%">
	</section><!--================End Home Banner Area =================-->

	<!--================Single Product Area =================-->
	<!-- <div class="product_image_area">
		<div class="container">
			<div class="row s_product_inner">
				<div class="col-lg-6">
					<div class="s_product_img">
						<div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
							<ol class="carousel-indicators">
								<li data-target="#carouselExampleIndicators" data-slide-to="0" class="active">
									<img src="img/product/single-product/s-product-s-2.jpg" alt="">
								</li>
								<li data-target="#carouselExampleIndicators" data-slide-to="1">
									<img src="img/product/single-product/s-product-s-3.jpg" alt="">
								</li>
								<li data-target="#carouselExampleIndicators" data-slide-to="2">
									<img src="img/product/single-product/s-product-s-4.jpg" alt="">
								</li>
							</ol>
							<div class="carousel-inner">
								<div class="carousel-item active">
									<img class="d-block w-100" src="img/product/single-product/s-product-1.jpg" alt="First slide">
								</div>
								<div class="carousel-item">
									<img class="d-block w-100" src="img/product/single-product/s-product-1.jpg" alt="Second slide">
								</div>
								<div class="carousel-item">
									<img class="d-block w-100" src="img/product/single-product/s-product-1.jpg" alt="Third slide">
								</div>
							</div>
						</div>
					</div>
				</div>
				<div class="col-lg-5 offset-lg-1">
					<div class="s_product_text">
						<h3>Faded SkyBlu Denim Jeans</h3>
						<h2>$149.99</h2>
						<ul class="list">
							<li>
								<a class="active" href="#">
									<span>Category</span> : Household</a>
							</li>
							<li>
								<a href="#">
									<span>Availibility</span> : In Stock</a>
							</li>
						</ul>
						<p>Mill Oil is an innovative oil filled radiator with the most modern technology. If you are looking for something that
							can make your interior look awesome, and at the same time give you the pleasant warm feeling during the winter.</p>
						<div class="product_count">
							<label for="qty">Quantity:</label>
							<input type="text" name="qty" id="sst" maxlength="12" value="1" title="Quantity:" class="input-text qty">
							<button onclick="var result = document.getElementById('sst'); var sst = result.value; if( !isNaN( sst )) result.value++;return false;"
							 class="increase items-count" type="button">
								<i class="lnr lnr-chevron-up"></i>
							</button>
							<button onclick="var result = document.getElementById('sst'); var sst = result.value; if( !isNaN( sst ) &amp;&amp; sst > 0 ) result.value--;return false;"
							 class="reduced items-count" type="button">
								<i class="lnr lnr-chevron-down"></i>
							</button>
						</div>
						<div class="card_area">
							<a class="main_btn" href="#">Add to Cart</a>
							<a class="icon_btn" href="#">
								<i class="lnr lnr lnr-diamond"></i>
							</a>
							<a class="icon_btn" href="#">
								<i class="lnr lnr lnr-heart"></i>
							</a>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
	 --><!--================End Single Product Area =================-->

	<!--================Product Description Area =================-->
	<section class="product_description_area">
		<div class="container">
			<ul class="nav nav-tabs" id="myTab" role="tablist">
				
				<li class="nav-item">
					<a class="nav-link active" data-toggle="tab" href="#MazeloFruitJelly" role="tab" aria-controls="MazeloFruitJelly" aria-selected="true">Mazelo Fruit Jelly Range</a>
				</li>
				<li class="nav-item">
					<a class="nav-link" data-toggle="tab" href="#Mazelo" role="tab" aria-controls="Mazelo" aria-selected="true">Mazelo Range</a>
				</li>
				<li class="nav-item">
					<a class="nav-link"  data-toggle="tab" href="#Kismi" role="tab" aria-controls="Kismi" aria-selected="true">Kismi Range</a>
				</li>
				<li class="nav-item">
					<a class="nav-link" data-toggle="tab" href="#Poppins" role="tab" aria-controls="Poppins" aria-selected="true">Poppins</a>
				</li>
				<li class="nav-item">
					<a class="nav-link" data-toggle="tab" href="#Melody" role="tab" aria-controls="Melody" aria-selected="true">Melody </a>
				</li>
				<li class="nav-item">
					<a class="nav-link" data-toggle="tab" href="#Londonderry" role="tab" aria-controls="Londonderry" aria-selected="true">Londonderry</a>
				</li>
				<li class="nav-item">
					<a class="nav-link" data-toggle="tab" href="#Eclairs" role="tab" aria-controls="Eclairs" aria-selected="true">Eclairs</a>
				</li>
				<li class="nav-item">
					<a class="nav-link" data-toggle="tab" href="#Friberg" role="tab" aria-controls="Friberg" aria-selected="true">Friberg</a>
				</li>
			</ul>
			


			<div class="tab-content" id="myTabContent">

				
				<div class="tab-pane fade active" id="MazeloFruitJelly" value="MazeloFruitJelly" role="tabpanel" aria-labelledby="MazeloFruitJelly-tab">
					<div class="row">
						
<?php
 $sql= "select * from product where Pro_Name like 'MazeloFruitJelly%'"; //"call sp()";
    $results=mysqli_query($db,$sql);
	foreach ($results as $result) 
	{?>
		<div class="col-lg-6"><center>
		<?php
        
		echo '<img src="'.$result['Image'].'"/>';	
		echo $result['Pro_Name']; 		
		echo '<br/>';
    	echo $result['MRP'].' ₹';		
    	echo '<br/>';
    	 echo '<input type="button" value="Add To Cart" onclick="addcart('.$result['P_ID'].')" />';
    	?>
   			</center></div>
    	<?php
	}

?>				</div>
				</div>


				<div class="tab-pane fade" id="Mazelo" value="Mazelo" role="tabpanel" aria-labelledby="Mazelo-tab">
					<div class="row">
<?php
 $sql= "select * from product where Pro_Name like 'Mazelo %'"; //"call sp()";
    $results=mysqli_query($db,$sql);
	foreach ($results as $result) 
	{?>
		<div class="col-lg-6"><center>
		<?php
        
		echo '<img src="'.$result['Image'].'"/>';	
		echo $result['Pro_Name']; 		
		echo '<br/>';
    	echo $result['MRP'].' ₹';		
    	echo '<br/>';
    	 echo '<input type="button" value="Add To Cart" onclick="addcart('.$result['P_ID'].')" />';
    	?>
   			</center></div>
    	<?php
	}

?>				</div>
				</div>
				

				<div class="tab-pane fade" id="Kismi" role="tabpanel" aria-labelledby="Kismi-tab">
					<div class="row">
<?php
 $sql= "select * from product where Pro_Name like 'Kismi%'"; //"call sp()";
    $results=mysqli_query($db,$sql);
	foreach ($results as $result) 
	{?>
		<div class="col-lg-6"><center>
		<?php
       
		echo '<img src="'.$result['Image'].'"/>';	
		echo $result['Pro_Name']; 		
		echo '<br/>';
    	echo $result['MRP'].' ₹';		
    	echo '<br/>';
    	 echo '<input type="button" value="Add To Cart" onclick="addcart('.$result['P_ID'].')" />';
    	?>
   			</center></div>
    	<?php
	}

?>				</div>
				</div>


				<div class="tab-pane fade" id="Poppins" role="tabpanel" aria-labelledby="Poppins-tab">
					<div class="row">
<?php
 $sql= "select * from product where Pro_Name like 'Poppins%'"; //"call sp()";
    $results=mysqli_query($db,$sql);
	foreach ($results as $result) 
	{?>
		<div class="col-lg-6"><center>
		<?php
       
		echo '<img src="'.$result['Image'].'"/>';	
		echo $result['Pro_Name']; 		
		echo '<br/>';
    	echo $result['MRP'].' ₹';		
    	echo '<br/>';
    	 echo '<input type="button" value="Add To Cart" onclick="addcart('.$result['P_ID'].')" />';
    	?>
   			</center></div>
    	<?php
	}

?>	
				</div>
				</div>


				<div class="tab-pane fade" id="Melody" role="tabpanel" aria-labelledby="Melody-tab">
					<div class="row">
						<?php
 $sql= "select * from product where Pro_Name like 'Melody%'"; //"call sp()";
    $results=mysqli_query($db,$sql);
	foreach ($results as $result) 
	{?>
		<div class="col-lg-6"><center>
		<?php
       
		echo '<img src="'.$result['Image'].'"/>';	
		echo $result['Pro_Name']; 		
		echo '<br/>';
    	echo $result['MRP'].' ₹';		
    	echo '<br/>';
    	 echo '<input type="button" value="Add To Cart" onclick="addcart('.$result['P_ID'].')" />';
    	?>
   			</center></div>
    	<?php
	}

?>				</div>
				</div>


				<div class="tab-pane fade" id="Londonderry" role="tabpanel" aria-labelledby="Londonderry-tab">
					<div class="row">
						<?php
 $sql= "select * from product where Pro_Name like 'Londonderry%'"; //"call sp()";
    $results=mysqli_query($db,$sql);
	foreach ($results as $result) 
	{?>
		<div class="col-lg-6"><center>
		<?php
        
		echo '<img src="'.$result['Image'].'"/>';	
		echo $result['Pro_Name']; 		
		echo '<br/>';
    	echo $result['MRP'].' ₹';		
    	echo '<br/>';
    	 echo '<input type="button" value="Add To Cart" onclick="addcart('.$result['P_ID'].')" />';
    	?>
   			</center></div>
    	<?php
	}

?>				</div>
				</div>


				<div class="tab-pane fade" id="Eclairs" role="tabpanel" aria-labelledby="Eclairs-tab">
					<div class="row">
						<?php
 $sql= "select * from product where Pro_Name like 'Eclairs%'"; //"call sp()";
    $results=mysqli_query($db,$sql);
	foreach ($results as $result) 
	{?>
		<div class="col-lg-6"><center>
		<?php
        
		echo '<img src="'.$result['Image'].'"/>';	
		echo $result['Pro_Name']; 		
		echo '<br/>';
    	echo $result['MRP'].' ₹';		
    	echo '<br/>';
    	 echo '<input type="button" value="Add To Cart" onclick="addcart('.$result['P_ID'].')" />';
    	?>
   			</center></div>
    	<?php
	}

?>				</div>
				</div>

				
				<div class="tab-pane fade" id="Friberg" role="tabpanel" aria-labelledby="Friberg-tab">
					<div class="row">
						<?php
 $sql= "select * from product where Pro_Name like 'Friberg%'"; //"call sp()";
    $results=mysqli_query($db,$sql);
	foreach ($results as $result) 
	{?>
		<div class="col-lg-6"><center>
		<?php
        
		echo '<img src="'.$result['Image'].'"/>';	
		echo $result['Pro_Name']; 		
		echo '<br/>';
    	echo $result['MRP'].' ₹';		
    	echo '<br/>';
    	 echo '<input type="button" value="Add To Cart" onclick="addcart('.$result['P_ID'].')" />';
    	?>
   			</center></div>
    	<?php
	}

?>				</div>
				</div>
			</div>

		</div>
	</section>
	<!--================End Product Description Area =================-->

	<!--================ Subscription Area ================-->
	<!--================ End Subscription Area ================-->

<?php
	require_once("footer.php");
?>

<script>
function addcart(pid) {
  var xhttp;   
  
  xhttp = new XMLHttpRequest();
  xhttp.onreadystatechange = function() {
    if (this.readyState == 4 && this.status == 200) {
        if(this.responseText==0)
            window.location.href = "login.php";
      alert(this.responseText);
    }
  };
  xhttp.open("GET", "cart.php?P_ID="+pid, true);
  xhttp.send();
}
</script>

	<!-- Optional JavaScript -->
	<!-- jQuery first, then Popper.js, then Bootstrap JS -->
	<script src="js/jquery-3.2.1.min.js"></script>
	<script src="js/popper.js"></script>
	<script src="js/bootstrap.min.js"></script>
	<script src="js/stellar.js"></script>
	<script src="vendors/lightbox/simpleLightbox.min.js"></script>
	<script src="vendors/nice-select/js/jquery.nice-select.min.js"></script>
	<script src="vendors/isotope/imagesloaded.pkgd.min.js"></script>
	<script src="vendors/isotope/isotope-min.js"></script>
	<script src="vendors/owl-carousel/owl.carousel.min.js"></script>
	<script src="js/jquery.ajaxchimp.min.js"></script>
	<script src="js/mail-script.js"></script>
	<script src="vendors/jquery-ui/jquery-ui.js"></script>
	<script src="vendors/counter-up/jquery.waypoints.min.js"></script>
	<script src="vendors/counter-up/jquery.counterup.js"></script>
	<script src="js/theme.js"></script>
</body>

</html>