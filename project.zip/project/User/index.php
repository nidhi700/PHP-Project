<!doctype html>
<html lang="en">
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">

<style>
body { background-color: #fff; color: #000; padding: 0; margin: 0; }
.container { width: 1000px; margin: auto; padding-top: 1em; }
.container .ism-slider { margin-left: auto; margin-right: auto; }
</style>

<link rel="stylesheet" href="ism/css/my-slider.css"/>
<script src="ism/js/ism-2.2.min.js"></script>

<style>

.container {
  position: relative;
  font-family: fantasy;
}

.text{
	margin-top: 50%;
	color: red;
	font-family: fantasy;
}

.text1{
	font-family: fantasy;
	padding: 20px;
	margin-top: 10%;
	color: white;
	letter-spacing: 2px;

}
.text-block {
	opacity: .7;
  position: absolute;
  bottom: 20px;
  right: 11px;
  background-color: black;
  color: white;
  height: 82%;
  width: 30%;
  top: 18%;
  
  
}
</style>
</head>
<body>

<?php
	require_once("header.php");
?>
	<!--================Home Banner Area =================-->
	<br/><br/><br/><br/><br/>
	

<div class="ism-slider" data-transition_type="zoom" data-play_type="loop" id="my-slider">
  <ol>
    <li>
      <img src="../img/banner1.png" width="100%" height="100%">
    </li>
    <li>
      <img src="../img/masala.png" width="100%" height="100%">
    </li>
    <li>
      <img src="../img/Melody.png" width="100%" height="100%">
    </li>
    <li>
      <img src="../img/bannermexitos.png" width="100%" height="100%">
    </li>
  </ol>
</div>
	
	<!--================End Home Banner Area =================-->

	<!--================Hot Deals Area =================-->
	<section class="hot_deals_area section_gap">
		<div class="container-fluid">
			<div class="row">
				<div class="col-lg-6">
					<div class="hot_deal_box">
						<img class="img-fluid" src="../img/Parle.png" alt="">
						<div class="content">
							<h2>Biscuits</h2>							
						</div>
						<a class="hot_deal_link" href="Biscuits.php"></a>
					</div>
				</div>

				<div class="col-lg-6">
					<div class="hot_deal_box">
						<img class="img-fluid" src="../img/index.png" alt="">
						<div class="content">
							<h2>Confectionery</h2>							
						</div>
						<a class="hot_deal_link" href="Confectionery.php"></a>
					</div>
				</div>
			</div>
			<br>
			<div class="row">
				<div class="col-lg-6">
					<div class="hot_deal_box">
						<img class="img-fluid" src="../img/Rusk.png" alt="">
						<div class="content">
							<h2>Rusk</h2>							
						</div>
						<a class="hot_deal_link" href="Rusk.php"></a>
					</div>
				</div>

				<div class="col-lg-6">
					<div class="hot_deal_box">
						<img class="img-fluid" src="../img/FullToss.png" alt="">
						<div class="content">
							<h2>Snacks</h2>							
						</div>
						<a class="hot_deal_link" href="Snacks.php"></a>
					</div>
				</div>
			</div>
		</div>
	</section>
	<!--================End Hot Deals Area =================-->

	<!--================Clients Logo Area =================-->
	<!-- <section class="clients_logo_area">
		<div class="container-fluid">
			<div class="clients_slider owl-carousel">
				<div class="item">
					<img src="../img/clients-logo/c-logo-1.png" alt="">
				</div>
				<div class="item">
					<img src="../img/clients-logo/c-logo-2.png" alt="">
				</div>
				<div class="item">
					<img src="../img/clients-logo/c-logo-3.png" alt="">
				</div>
				<div class="item">
					<img src="../img/clients-logo/c-logo-4.png" alt="">
				</div>
				<div class="item">
					<img src="../img/clients-logo/c-logo-5.png" alt="">
				</div>
			</div>
		</div>
	</section> -->
	<!--================End Clients Logo Area =================-->
	<div class="container">
		<div class="main_title">
			<h2>Our Legacy</h2>
			<p>Discover Our Heritage</p>
		</div>
 		<img src="../img/history.png" alt="History" style="width:100%;">
  		<div class="text-block">
  		<center>
    		<div class="text"><h1>1929</h1></div>
    		<div class="text1"><h3> Our first factory was set up with just 12 people manufacturing Confectionery.</h3></div>
    	</center>
  		</div>
	</div>

	<!--================Feature Product Area =================-->
	
	<!--================End Feature Product Area =================-->

	<!--================ Subscription Area ================-->
	<!--================ End Subscription Area ================-->

<?php
	require_once("footer.php");
?>
	<!-- Optional JavaScript -->
	<!-- jQuery first, then Popper.js, then Bootstrap JS -->
	<script src="js/jquery-3.2.1.min.js"></script>
	<script src="js/popper.js"></script>
	<script src="js/bootstrap.min.js"></script>
	<script src="js/stellar.js"></script>
	<script src="vendors/lightbox/simpleLightbox.min.js"></script>
	<script src="vendors/nice-select/js/jquery.nice-select.min.js"></script>
	<script src="vendors/isotope/imagesloaded.pkgd.min.js"></script>
	<script src="vendors/isotope/isotope-min.js"></script>
	<script src="vendors/owl-carousel/owl.carousel.min.js"></script>
	<script src="js/jquery.ajaxchimp.min.js"></script>
	<script src="vendors/counter-up/jquery.waypoints.min.js"></script>
	<script src="vendors/flipclock/timer.js"></script>
	<script src="vendors/counter-up/jquery.counterup.js"></script>
	<script src="js/mail-script.js"></script>
	<script src="js/theme.js"></script>

</body>

</html>