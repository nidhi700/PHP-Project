<!Doctype html>
<html lang="en">
<?php //session_start(); 
	require_once('db.php');

?>
<head>
	<!-- Required meta tags -->
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	
	<title>Parle</title>
	<!-- Bootstrap CSS -->
  	<link rel="icon" type="image/x-icon" class="js-site-favicon" href="../img/logo1.ico">
	<link rel="stylesheet" href="css/bootstrap.css">
	<link rel="stylesheet" href="vendors/linericon/style.css">
	<link rel="stylesheet" href="css/font-awesome.min.css">
	<link rel="stylesheet" href="vendors/owl-carousel/owl.carousel.min.css">
	<link rel="stylesheet" href="vendors/lightbox/simpleLightbox.css">
	<link rel="stylesheet" href="vendors/nice-select/css/nice-select.css">
	<link rel="stylesheet" href="vendors/animate-css/animate.css">
	<link rel="stylesheet" href="vendors/jquery-ui/jquery-ui.css">
	<!-- main css -->
	<link rel="stylesheet" href="css/style.css">
	<link rel="stylesheet" href="css/responsive.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.4/jquery.min.js"></script>

<script type="text/javascript">
$(window).load(function() {
    $(".loader").fadeOut("slow");
});
</script>

<style >
	.loader {
    position: fixed;
    left: 0px;
    top: 0px;
    width: 100%;
    height: 100%;
    z-index: 9999;
    background: url('../img/logo.png') 50% 50% no-repeat rgb(249,249,249);
    opacity: .8;
}
</style>

</head>

<body>
											
								
	<!--================Header Menu Area =================-->
	<header class="header_area">
		<div class="main_menu">
			<nav class="navbar navbar-expand-lg navbar-light">
				<div class="container-fluid">
					<!-- Brand and toggle get grouped for better mobile display -->
					<a class="navbar-brand logo_h" href="index.php">
						<img src="../img/logo.png" alt="Logo">
					</a>
					<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent"
					 aria-expanded="false" aria-label="Toggle navigation">
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
					</button>
					<!-- Collect the nav links, forms, and other content for toggling -->
					<div class="collapse navbar-collapse offset" id="navbarSupportedContent">
						<div class="row w-100">
							<div class="col-lg-7 pr-0">
								<ul class="nav navbar-nav center_nav pull-right">
									<li class="nav-item active">
										<a class="nav-link dropdown-toggle" href="index.php">Home</a>
									</li>
									<li class="nav-item submenu dropdown">
										<a href="#" class="nav-link dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Brands</a>
										<ul class="dropdown-menu">
											<li class="nav-item">
												<a class="nav-link" href="Biscuits.php">Biscuits</a>
												<li class="nav-item">
													<a class="nav-link" href="Confectionery.php">Confectionery</a>
													<li class="nav-item">
														<a class="nav-link" href="Rusk.php">Rusk</a>
														<li class="nav-item">
															<a class="nav-link" href="Snacks.php">Snacks</a>
														</li>								
										</ul>
										</li>
										<li class="nav-item ">
										<a class="nav-link dropdown-toggle" href="blog.php">About</a>
									</li>
										<li class="nav-item">
												<a class="nav-link" href="contact.php">Contact</a>
										</li>
<?php
if(isset($_SESSION['name'])){
   ?>
										<li class="nav-item">
											<a href="logout.php" class="nav-link">
									Logout</a>
										</li>
										<li class="nav-item">
											<a href="history.php" class="nav-link">
									Your Orders</a>
										</li>
<?php	} ?>	
							</div>						

							<div class="col-lg-5">
								<ul class="nav navbar-nav navbar-right right_nav pull-right">
									<!-- <hr>
									<li class="nav-item">
										<a href="#" class="icons">
											<i class="fa fa-search" aria-hidden="true"></i>
										</a>
									</li>
									<hr>
 -->
<?php
if(isset($_SESSION['name'])){
	?>
								
									<li class="nav-item"><br/>
										<center>
										<?php echo '<a href="profile.php">Welcome <br>';
										echo $_SESSION['name']."</a>";   ?>
										</center>
									</li>
								
<?php } 
else {?>
								
									<li class="nav-item">
										<a href="login.php" class="icons">
											<i class="fa fa-user" aria-hidden="true"></i>
										</a>
									</li>
								
<?php }
?>

								

									<!-- <li class="nav-item">
										<a href="#" class="icons">
											<i class="fa fa-heart-o" aria-hidden="true"></i>
										</a>
									</li> -->

									<hr>

									<li class="nav-item">
										<a href="cart_view.php" class="icons">
											<i class="lnr lnr lnr-cart"></i>
										</a>
									</li>

									
								</ul>
							</div>
						</div>
					</div>
				</div>
			</nav>
		</div>
	</header>