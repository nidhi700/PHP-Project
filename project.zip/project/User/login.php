<?php  
	require_once('db.php');
	if(isset($_POST['submit']))
	{
		$unm=$_POST['name'];
		$pwd=$_POST['pwd'];
		$_SESSION['logged']=null;
		if($unm!=null && $pwd!=null)
		{
			include('mysql_crud.php');
			$db = new Database();
			$db->connect();
			$db->select('login','Cust_Id,Name',NULL,"User_Id = '".$unm."' && Password = '".$pwd."'");
			$res = $db->getResult();
			
			if($res[0]['Name']!=null)
			{
				$_SESSION['name']=$res[0]['Name'];
				$_SESSION['logged']=true;
				$_SESSION['id']=$res[0]['Cust_Id'];
				header("location: index.php");	
			}
			else
			{
				//$_SESSION['logged']=false;
				echo '<script language="javascript">';
	         	echo 'alert ("Invalid UserId & Password")';
	         	echo '</script>';	
			}
		}
		else
		{
			echo '<script language="javascript">';
	        echo 'alert ("Enter UserId & Password")';
	        echo '</script>';	
	        
	    }
	}


?>

<!doctype html>
<html lang="en">
<body>

	<!--================Header Menu Area =================-->
	<?php require_once('header.php'); ?>
	<!--================Header Menu Area =================-->

	<!--================Home Banner Area =================-->
	<br/><br/><br/><section class="banner_area">
		<img src="../img/aboutus.png" width="100%">
	</section><!--================End Home Banner Area =================-->

	<!--================Login Box Area =================-->
	<section class="login_box_area p_120">
		<div class="container">
			<div class="row">
				<div class="col-lg-6">
					<div class="login_box_img">
						<img class="img-fluid" src="../img/login.jpg" alt="">
						<div class="hover">
							<h4>New to our website?</h4>
							
							<a class="main_btn" href="registration.php">Create an Account</a>
						</div>
					</div>
				</div>
				<div class="col-lg-6">
					<div class="login_form_inner">
						<h3>Log in to enter</h3>
						<form class="row login_form" action="" method="post" id="contactForm" novalidate="novalidate">
							<div class="col-md-12 form-group">
								<input type="text" class="form-control" id="name" name="name" placeholder="Username">

							</div>
							<div class="col-md-12 form-group">
								<input type="password" class="form-control" id="pwd" name="pwd" placeholder="Password">
							</div>
							<!-- <div class="col-md-12 form-group">
								<div class="creat_account">
									<input type="checkbox" id="f-option2" name="selector">
									<label for="f-option2">Keep me logged in</label>
								</div>
							</div> -->
							<div class="col-md-12 form-group">
								<button type="submit" value="submit" name="submit" class="btn submit_btn">Log In</button>
								<a href="../admin/edit_user.php">Forgot Password?</a>
							</div>
						</form>
					</div>
				</div>
			</div>
		</div>
	</section>
	<!--================End Login Box Area =================-->

	<!--================ Subscription Area ================-->
	
	<!--================ End Subscription Area ================-->

	<!--================ start footer Area  =================-->
	<?php require_once('footer.php'); ?>
	<!--================ End footer Area  =================-->




	<!-- Optional JavaScript -->
	<!-- jQuery first, then Popper.js, then Bootstrap JS -->
	<script src="js/jquery-3.2.1.min.js"></script>
	<script src="js/popper.js"></script>
	<script src="js/bootstrap.min.js"></script>
	<script src="js/stellar.js"></script>
	<script src="vendors/lightbox/simpleLightbox.min.js"></script>
	<script src="vendors/nice-select/js/jquery.nice-select.min.js"></script>
	<script src="vendors/isotope/imagesloaded.pkgd.min.js"></script>
	<script src="vendors/isotope/isotope-min.js"></script>
	<script src="vendors/owl-carousel/owl.carousel.min.js"></script>
	<script src="js/jquery.ajaxchimp.min.js"></script>
	<script src="js/mail-script.js"></script>
	<script src="vendors/jquery-ui/jquery-ui.js"></script>
	<script src="vendors/counter-up/jquery.waypoints.min.js"></script>
	<script src="vendors/counter-up/jquery.counterup.js"></script>
	<script src="js/theme.js"></script>

</body>

</html>