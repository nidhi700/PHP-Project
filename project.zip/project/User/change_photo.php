<?php 
require_once('db.php');
	$db=mysqli_connect("localhost","root","","parle");
	$name=$_POST['name'];    
    
    $sql= "select * from product where pro_name like '$name%'"; //"call sp()";
    $results=mysqli_query($db,$sql);
   	
   	?>
   	<center>
   	<?php
   	if($name=='View All'){ 
   		echo '<img src="../img/Hide&Seek.png" width="100%" height="100%" />';
   	}
   	else{
   	   	foreach ($results as $result) {
          echo '<img src="'.$result['Image'].'"/>';	
		      echo 'Name = '.$result['Pro_Name']; echo '&nbsp;&nbsp;&nbsp;';
          echo $result['MRP'].'₹';echo '&nbsp;&nbsp;&nbsp;';
          echo '<input type="button" value="Add To Cart" onclick="addcart('.$result['P_ID'].')" />';
	}}
	
?></center>


  <script>
function addcart(pid) {
  var xhttp;   
  
  xhttp = new XMLHttpRequest();
  xhttp.onreadystatechange = function() {
    if (this.readyState == 4 && this.status == 200) {
        if(this.responseText==0)
            window.location.href = "login.php";
      alert(this.responseText);
    }
  };
  xhttp.open("GET", "cart.php?P_ID="+pid, true);
  xhttp.send();
}
</script>
