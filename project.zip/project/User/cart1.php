<?php
require_once('db.php');
 
if(!isset($_SESSION['id']))
{
	header("location: login.php");
}
else
{
  	$uid=$_SESSION['id'];
 	$id= $_GET['P_ID'];
 	$pcs= $_GET['Pieces_C'];
 	$sql="select Pieces_C from addtocart where Cust_Id=$uid and P_ID=$id";
 	$result=mysqli_query($db,$sql);
 	$row = mysqli_fetch_assoc($result);
 	

 	if($row['Pieces_C']>0)
 	{
 		if($pcs=='p')
 		{
 			$sql="update  addtocart set Pieces_C=Pieces_C+1  where Cust_Id=$uid and P_ID=$id";
 		}
 		else
 		{
 			$sql="update  addtocart set Pieces_C=Pieces_C-1  where Cust_Id=$uid and P_ID=$id"; 					
 		}
   	}	
	else
  		$sql="insert into addtocart(Cust_Id,P_ID,Pieces_C) values($uid,$id,1)"; 	

 	if(mysqli_query($db,$sql))
	 { 		
 		$a="delete from addtocart where Pieces_C=0";
 		mysqli_query($db,$a);	
 		header("location: cart_view.php");
  	}
 	else
  		echo "Somthing Wrong";
}
?>
