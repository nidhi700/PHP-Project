<?php
require_once('db.php');
if($_SESSION['name']==null)
{
	header("location: login.php");	
}
else
{
	$uid=$_SESSION['id'];	
	$sql1= "select * from addtocart where Cust_Id=$uid";
	$results1=mysqli_query($db,$sql1);
	$row1 = mysqli_fetch_assoc($results1);

	if($row1['Cust_Id']!=null){

	
	$sql= "select * from login where Cust_Id=$uid";
	$results=mysqli_query($db,$sql);
	$row = mysqli_fetch_assoc($results);	
	$name=$row['Name'];
	$mob1=$row['Contact'];
	$add=$row['Shop_Add'];

	
?>


<!doctype html>
<html lang="en">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

	<title>Parle</title>
	  	<link rel="icon" type="image/x-icon" class="js-site-favicon" href="../img/logo1.ico">


<style type="text/css">
	.image1{
		margin-top: 4%;
	}
	.form1{
		color: black;
	}
</style>

</head>

<body>


<img src="../img/MagixCreme1.png" width="100%">
 <center>
		<div class="image1">
			<a href="index.php"><img src="../img/logo.png" width="10%" height="10%"></a> &nbsp;
			<u class="form1"><a href="cart_view.php">CheckOut</a>   ->   Payment</u>
		</div>
	</center>    
	<!--================Checkout Area =================-->
	<section class="checkout_area section_gap">
		<div class="container">
			
			 <div class="billing_details">
				<div class="row">

					<div class="col-lg-12">
						<div class="order_box">
							<h2>User Details</h2>
							<ul class="list">
								<li>
									<?php echo "Name : ".$name."<br>"; ?>
									<?php echo "Contact : ".$mob1."<br>"; ?>
									<?php echo "Billing Address : ".$add; ?>
									
								</li>
							</ul>
						</div>	
							
	<form action="order.php" method="post" id="payment_form">
   				<div class="order_box">
							<h2>Your Order</h2>
							<ul class="list">
								<li>
									<a href="#">Product
										<span>Total</span>
									</a>
								</li>
					<?php 	

	$sql1= "select * from addtocart a ,product p where p.P_ID=a.P_ID and Cust_Id=$uid";
	$tot=0;
	$result=mysqli_query($db,$sql1);
	while($row1 = mysqli_fetch_assoc($result))
	{		
		
									?>
								<li>
									<a href=""><?php echo $row1['Pro_Name']; ?>
									<span class="middle">X &nbsp; <?php echo $row1['Pieces_C']; ?></span>

									<span class="last"><?php echo "₹ ".$row1['Pieces_C']*$row1['MRP']; ?></span>
									</a>
								</li>
							<?php }
						 ?>
							</ul>
							<ul class="list list_2">
								<li>
									<a href="">FinalTotal
										<span><?php echo "Rs. ".$_SESSION['total']; ?></span>
									</a>
								</li>
								
							</ul>
							<div class="payment_item">
								<input type="radio" name="payment" value="cash" checked> Cash On Delivery 
								<br>
								<input type="radio" name="payment" value="Online"> PayUMoney
								<br>
									<img src="../img/product/single-product/card.jpg" alt="">
									<div class="check"></div>
							</div>
							<center>
								<input class="main_btn" type="submit" name="pay" value="Pay"/>
							</center>
							</div>
						</form>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>
					
	<!--================End Checkout Area =================-->

<script type="text/javascript">
	<!--
/*$('#payment_form').bind('keyup blur', function(){
	$.ajax({
          url: 'index.php',
          type: 'post',
          data: JSON.stringify({ 
            key: $('#key').val(),
			salt: $('#salt').val(),
			txnid: $('#txnid').val(),
			amount: $('#amount').val(),
		    pinfo: $('#pinfo').val(),
            fname: $('#fname').val(),
			email: $('#email').val(),
			mobile: $('#mobile').val(),
			udf5: $('#udf5').val()
          }),
		  contentType: "application/json",
          dataType: 'json',
          success: function(json) {
            if (json['error']) {
			 $('#alertinfo').html('<i class="fa fa-info-circle"></i>'+json['error']);
            }
			else if (json['success']) {	
				$('#hash').val(json['success']);
            }
          }
        }); 
});*/
//-->
</script>
<script type="text/javascript"><!--
function launchBOLT()
{
	bolt.launch({
	key: $('#key').val(),
	txnid: $('#txnid').val(), 
	//hash: $('#hash').val(),
	amount: $('#amount').val(),
	firstname: $('#fname').val(),
	email: $('#email').val(),
	phone: $('#mobile').val(),
	productinfo: $('#pinfo').val(),
	udf5: $('#udf5').val(),
	surl : $('#surl').val(),
	furl: $('#surl').val(),
	mode: 'dropout'	
},{ responseHandler: function(BOLT){
	console.log( BOLT.response.txnStatus );		
	if(BOLT.response.txnStatus != 'CANCEL')
	{
		//Salt is passd here for demo purpose only. For practical use keep salt at server side only.
		var fr = '<form action=\"'+$('#surl').val()+'\" method=\"post\">' +
		'<input type=\"hidden\" name=\"key\" value=\"'+BOLT.response.key+'\" />' +
		'<input type=\"hidden\" name=\"salt\" value=\"'+$('#salt').val()+'\" />' +
		'<input type=\"hidden\" name=\"txnid\" value=\"'+BOLT.response.txnid+'\" />' +
		'<input type=\"hidden\" name=\"amount\" value=\"'+BOLT.response.amount+'\" />' +
		'<input type=\"hidden\" name=\"productinfo\" value=\"'+BOLT.response.productinfo+'\" />' +
		'<input type=\"hidden\" name=\"firstname\" value=\"'+BOLT.response.firstname+'\" />' +
		'<input type=\"hidden\" name=\"email\" value=\"'+BOLT.response.email+'\" />' +
		'<input type=\"hidden\" name=\"udf5\" value=\"'+BOLT.response.udf5+'\" />' +
		'<input type=\"hidden\" name=\"mihpayid\" value=\"'+BOLT.response.mihpayid+'\" />' +
		'<input type=\"hidden\" name=\"status\" value=\"'+BOLT.response.status+'\" />' +
		//'<input type=\"hidden\" name=\"hash\" value=\"'+BOLT.response.hash+'\" />' +
		'</form>';
		var form = jQuery(fr);
		jQuery('body').append(form);								
		form.submit();
	}
},
	catchException: function(BOLT){
 		alert( BOLT.message );
	}
});
}
//--

</script>	


<?php
	require_once("footer.php");

?>


<!-- 
<div background="#000000">
	<div class="footer-nav">
		dktdk
	</div>
</div>

<div class="col-lg-3 col-md-3 visible-lg-block hidden-md hidden-xs hidden-sm">
	
		5jgkj8
	
</div>
<div class="col-lg-3 col-md-3 visible-lg-block hidden-md hidden-xs hidden-sm">
	<div class="footer-nav">
		4786
	</div>
</div> -->

	<!-- Optional JavaScript -->
	<!-- jQuery first, then Popper.js, then Bootstrap JS -->
	<script src="js/popper.js"></script>
	<script src="js/bootstrap.min.js"></script>
	<script src="js/stellar.js"></script>
	<script src="vendors/lightbox/simpleLightbox.min.js"></script>
	<script src="vendors/nice-select/js/jquery.nice-select.min.js"></script>
	<script src="vendors/isotope/imagesloaded.pkgd.min.js"></script>
	<script src="vendors/isotope/isotope-min.js"></script>
	<script src="vendors/owl-carousel/owl.carousel.min.js"></script>
	<script src="js/jquery.ajaxchimp.min.js"></script>
	<script src="js/mail-script.js"></script>
	<script src="vendors/jquery-ui/jquery-ui.js"></script>
	<script src="vendors/counter-up/jquery.waypoints.min.js"></script>
	<script src="vendors/counter-up/jquery.counterup.js"></script>
	<script src="js/theme.js"></script>

<?php } 
	else
	{
		echo '<script language="javascript">';
	    echo 'alert ("Your Cart Is Empty")';
	    echo '</script>';	
	    //header("location: index.php");
	}
}
?>
</body>

</html>
