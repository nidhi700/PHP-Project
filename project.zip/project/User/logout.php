<?php
require_once('db.php');
//session_start();
$_SESSION['logged']=null;
session_destroy();
header('location: login.php');


?>