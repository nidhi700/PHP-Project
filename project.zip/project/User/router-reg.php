<?php
require_once("db.php");
 if($_SERVER["REQUEST_METHOD"] == "POST") 
 {
      // username and password sent from form 
      
      $nm=$_POST['Name'];
      $user_id=$_POST['User_Id'];
	  $password=$_POST['Password'];
	  $cpassword=$_POST['ConfirmPassword'];
	  $shopname=$_POST["ShopName"];
	  $shopadd=$_POST["Shop_Add"];
	  $contact=$_POST["Contact"];
	  $gst=$_POST['GST'];
	  $img = "../img/" . basename( $_FILES['pimg1']['name']);
		move_uploaded_file( $_FILES['pimg1']['tmp_name'] , $img);

      
	  if($password==$cpassword)
	  {
		  $sql = "SELECT * FROM login WHERE User_Id = '$user_id'";
	      $result = mysqli_query($db,$sql);
	      $row = mysqli_fetch_array($result,MYSQLI_ASSOC);
	      $count = mysqli_num_rows($result);
			if($count==1)
			{			 
				echo '<script language="javascript">';
	         	echo 'alert ("user exist")';
	         	echo '</script>';
			}
			else
			{
				include('mysql_crud.php');
				$db = new Database();
				$db->connect();
				$db->insert('login',array('Name'=>$nm,'ShopName'=>$shopname,'Shop_Add'=>$shopadd,'Contact'=>$contact,'GST'=>$gst,'User_Id'=>$user_id,'Password'=>$password,'Image'=>$img));  // Table name, column names and respective values
				$res = $db->getResult();  
				//print_r($res);
				if($res)
				{
					header('location: login.php');
				}
	        
				else
				{
					header('location: registration.php');
				}
			}
		}
	  	else
	  	{
         	header('location: registration.php');
      	}
      }
?>
