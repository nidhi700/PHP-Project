<?php
	session_start();
	$db=mysqli_connect("localhost","root","","parle");
	//echo "<a href=logout.php>Logout</a>";
?>