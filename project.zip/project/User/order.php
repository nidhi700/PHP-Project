<?php
	require_once('db.php');
	if($_SESSION['name']==null)
	{
		header("location: login.php");	
	}
	else
	{
		$a1="";
		$a2="";
		$a3="";
		if(isset($_POST['pay']))
		{
			$type=$_POST['payment'];
			$_SESSION['order_id']=rand(1,1000);
			$type1=$_SESSION['order_id'];
			$user_id=$_SESSION['id'];
			$amount=$_SESSION['total'];

			
	$sql1 = "select * from product p, addtocart a where Cust_Id=$user_id and p.P_ID=a.P_ID";
	$result = mysqli_query($db,$sql1);
	while($row1 = mysqli_fetch_assoc($result))
	{		
		$a1=$row1['Pro_Code'];
		$a2=$row1['MRP'];
		$a3=$row1['Pieces_C'];
		$sql12="insert into order_detail(Order_id,Cust_Id,Pro_Code,MRP,Pieces_O) values ($typ1,$user_id,$a1,$a2,$a3)";
		print_r(mysqli_query($db,$sql12));
	}
	
	$sql="insert into order_master1(Order_id,Cust_Id,Amount,Date_order,Payment_Type) values ($type1,$user_id,$amount,now(),'$type')";
	
			if(mysqli_query($db,$sql))
			{
				$a="delete from addtocart where Cust_Id=$user_id";
				mysqli_query($db,$a);
				header("location: bill.php");	
			}		
		}
	}



?>