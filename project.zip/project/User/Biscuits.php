<!doctype html>
<html lang="en">
<head>
	<script src="js/jquery-3.2.1.min.js"></script>
<?php require_once('design.php'); ?>



<body>

	<!--================Header Menu Area =================-->
	<?php require_once('header.php'); ?><!--================Header Menu Area =================-->

	<!--================Home Banner Area =================-->
	<br/><br/>
	<section class="banner_area">
		<img src="../img/bannermo.png" width="100%">
	</section><!--================End Home Banner Area =================-->
					 <br>
					 <div class="abc"><h3>Select Brand Family :</h3></div>
					 	<div class="text-block"><div class="text1">
					 		
					 		<select onchange="changephoto()" id="category">
									<option value="View All">
										View All
									</option>
									<option value="Parle-G">
										Parle-G Range
									</option>
									
									<option value="Hide&Seek">
										Hide & Seek Range
									</option>

									<option value="HappyHappy">
										Happy Happy Range
									</option>

									<option value="Monaco">
										Monaco Range
									</option>

									<option value="Krackjack">
										Krackjack Range
									</option>

									<option value="Milano">
										Milano Range
									</option>
									
								</select>
							</div></div>
							<br/><br/><br/><br/><br/>
							<div id="show">
						<img src="../img/Hide&Seek.png" width="100%" height="100%" />
					</div>
				</div>
			</div>

		
		</div>
	</section>
	<!--================End Category Product Area =================-->

	<!--================ Subscription Area ================-->
	
	<!--================ End Subscription Area ================-->

	<!--================ start footer Area  =================-->
	<?php require_once('footer.php');?><!--================ End footer Area  =================-->


	<script>
		function changephoto(){
		$(document).ready(function() {
			// $("#definition_description").html($("#description").val());
			$.ajax({
				url: 'change_photo.php',
				type: 'POST',
				// dataType: 'default: Intelligent Guess (Other values: xml, json, script, or html)',
				data: {name:$("#category").val()},
				success:function(data){
					$("#show").html(data);
				},
			});
		

		});
	}
	</script>




	<!-- Optional JavaScript -->
	<!-- jQuery first, then Popper.js, then Bootstrap JS -->
	<script src="js/jquery-3.2.1.min.js"></script>
	<script src="js/popper.js"></script>
	<script src="js/bootstrap.min.js"></script>
	<script src="js/stellar.js"></script>
	<script src="vendors/lightbox/simpleLightbox.min.js"></script>
	<script src="vendors/nice-select/js/jquery.nice-select.min.js"></script>
	<script src="vendors/isotope/imagesloaded.pkgd.min.js"></script>
	<script src="vendors/isotope/isotope-min.js"></script>
	<script src="vendors/owl-carousel/owl.carousel.min.js"></script>
	<script src="js/jquery.ajaxchimp.min.js"></script>
	<script src="js/mail-script.js"></script>
	<script src="vendors/jquery-ui/jquery-ui.js"></script>
	<script src="vendors/counter-up/jquery.waypoints.min.js"></script>
	<script src="vendors/counter-up/jquery.counterup.js"></script>
	<script src="js/theme.js"></script>
</body>

</html>