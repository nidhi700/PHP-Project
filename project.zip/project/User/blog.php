<!doctype html>
<html lang="en">

<body>
    <?php
        require_once("header.php");
    ?>
    <!--================Home Banner Area =================-->
    <br><br><br><br><br><br>
    <div class="container">
        <center><h3><u>Introduction</u></h3></center>
        <p>
             A long time ago, when the British ruled India, a small factory was set up by Mohanlal Dayal Chauhan in the suburbs of Mumbai city, to manufacture sweets and toffees. The year was 1929 and the market was dominated by famous international brands that were imported freely. Despite the odds and unequal competition, this company called Parle Products, survived and succeeded, by adhering to high quality and improvising from time to time.
A decade later, in 1939, Parle Products began manufacturing biscuits, in addition to sweets and toffees. Having already established a reputation for quality, the Parle brand name grew in strength with this diversification. Parle Glucose and Parle Monaco were the first brands of biscuits to be introduced, which later went on to become leading names for great taste and quality.
        </p>
         <center><h3><u>History</u></h3></center>
        <p>
             Parle-G or Parle Glucose biscuits, manufactured by Parle Products Pvt. Ltd, are one of the most popular biscuits in India. Parle-G is one of the oldest brand names as well as the largest selling brand of biscuits in India. For decades, the product was instantly recognized by its iconic white and yellow wax paper wrapper with the depiction of a young girl on the front. Parle-G has been a strong household name across India. The great taste, high nutrition, and the international quality, makes Parle-G a winner. No wonder, it's the undisputed leader in the biscuit category for decades. 
        </p>
        <p>
             Parle-G is consumed by people of all ages, from the rich to the poor, living in cities & in villages. While some have it for breakfast, for others it is a complete wholesome meal. For some it's the best accompaniment for chai, while for some it's a way of getting charged whenever they are low on energy. Because of this, Parle-G is the world's largest selling brand of biscuits. Launched in the year 1939, it was one of the first brands of Parle Products. It was called Parle Glucose Biscuits. The incredible demand led Parle to introduce the brand in special branded packs and in larger festive tin packs. By the year 1949, Parle Glucose biscuits were available not just in Mumbai but also across the state. It was also sold in parts of North India. The early 50s produced over 150 tons of biscuits produced in the Mumbai factory. Looking at the success of Parle-G, a lot of other me-too brands were introduced in the market. And these brands had names that were similar to Parle Glucose Biscuits. This forced Parle to change the name from Parle Glucose Biscuits to Parle-G. Originally packed in the wax paper pack; today it is available in a contemporary, premium BOPP pack with attractive side fins. The new airtight pack helps to keep the biscuits fresh and tastier for a longer period. Parle-G was the only biscuit brand that was always in short supply. It was heading towards becoming an all-time great brand of biscuit. Parle-G started being advertised in the 80's. 
        </p>
        <center><h3><u>THE STRENGTH OF THE BRAND</u></h3></center>
        <p>
             Over the years, Parle has grown to become a multi-million US Dollar company. Many of the Parle products - biscuits or confectionaries, are market leaders in their category.
Today, Parle enjoys a 40% share of the total biscuit market and a 15% share of the total confectionary market, in India. The Parle Biscuit brands, such as, Parle-G, Monaco and Krackjack and confectionery brands, such as, Melody, Poppins, Mangobite and Kismi, enjoy a strong imagery and appeal amongst consumers.
In this way, by concentrating on consumer tastes and preferences and emphasizing Research & Development, the Parle brand grows from strength to strength.

        </p>
        <center><h3><u> THE MARKETING STRENGTH</u></h3></center>
<p>
   The extensive distribution network, built over the years, is a major strength for Parle Products. Parle biscuits & Sweets are available to consumers, even in the most remote places. 
</p>
<p>
    Parle has nearly 1,500 wholesalers, catering to 4, 25,000 retail outlets directly or indirectly. A two hundred strong dedicated field force services these wholesalers & retailers. Additionally, there are 31 depots and C&F agents supplying goods to the wide distribution network. 
</p>
<p>
    The Parle marketing philosophy emphasizes catering to the masses. They constantly endeavor at designing products that provide nutrition & fun to the common man. Most Parle offerings are in the low & mid-range price segments. This is based on their understanding of the Indian consumer psyche. The value-for-money positioning helps generate large sales volumes for the products.
</p>
<p>
     However, Parle Products also manufactures a variety of premium products for the up-market, urban consumers. And in this way, caters a range of products to a variety of consumers.
  
</p>
    </div>
    <!--================Blog Area =================-->
<?php
    require_once("footer.php");
?>



    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="js/jquery-3.2.1.min.js"></script>
    <script src="js/popper.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/stellar.js"></script>
    <script src="vendors/lightbox/simpleLightbox.min.js"></script>
    <script src="vendors/nice-select/js/jquery.nice-select.min.js"></script>
    <script src="vendors/isotope/imagesloaded.pkgd.min.js"></script>
    <script src="vendors/isotope/isotope-min.js"></script>
    <script src="vendors/owl-carousel/owl.carousel.min.js"></script>
    <script src="vendors/jquery-ui/jquery-ui.js"></script>
    <script src="js/jquery.ajaxchimp.min.js"></script>
    <script src="js/mail-script.js"></script>
    <script src="vendors/jquery-ui/jquery-ui.js"></script>
    <script src="js/theme.js"></script>
</body>

</html>