<?php

	require_once('db.php');
	if($_SESSION['name']==null)
	{
		header("location: login.php");	
	}
	else
	{

    	$uid=$_SESSION['id'];
		$sql= "select * from login where Cust_Id=$uid";
		$results=mysqli_query($db,$sql);
		$row = mysqli_fetch_assoc($results);	
	
		?>

<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>

<?php require_once('header.php'); ?>
<br><br><br><br><br><br><br><br>
<div class="row">
	
	<div class="col-lg-6">
		<center>
			<?php
				if($row['Image']==null)
				{
					$a="../img/dman.png";
				}
				else
				{
					$a=$row['Image'];
				}
			?>

			<img src="<?php echo $a; ?>" width="200px" height="200px" ><br><br>
			<h3><?php echo $row['Name']; ?></h3>
		</center>
	</div>

	<div class="col-lg-6">
		<h3><pre>
	<?php echo "Shop Name      : ".$row['ShopName']; ?><br>
	<?php echo "Shop Address   : ".$row['Shop_Add']; ?><br>
	<?php echo "Phone Number   : ".$row['Contact']; ?><br>
	<?php echo "GST Number     : ".$row['GST']; ?><br>
	<?php echo "User ID        : ".$row['User_Id']; ?><br>
		</pre></h3>
		<center>
			<a href="edit_user.php?Cust_Id=<?php echo $row['Cust_Id'];?>"><button class="main_btn">Edit Information</button></a>
		</center>
	</div>
</div>

<br>
<?php require_once('footer.php'); ?>

</body>
</html>
<?php } ?>